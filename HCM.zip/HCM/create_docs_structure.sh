#!/bin/bash

# Base directory for your documentation
BASE_DIR="Docs/HCM"

# Modules list
MODULES=("HrCore" "time&attendance" "payroll" "totalreward" "ess" "recruitment")

# Subdirectories under base
SUBDIRS=("architecture" "concepts" "product" "technical")

# Function to create directory and markdown files
create_structure() {
    for SUBDIR in "${SUBDIRS[@]}"; do
        mkdir -p "$BASE_DIR/$SUBDIR"
        for MODULE in "${MODULES[@]}"; do
            # Create markdown files for each module
            MODULE_FILE="$BASE_DIR/$SUBDIR/$MODULE.md"
            echo "# $MODULE in $SUBDIR" > "$MODULE_FILE"
            echo "Documentation for the $MODULE module under the $SUBDIR section." >> "$MODULE_FILE"
        done
    done

    # Create _sidebar.md file
    SIDEBAR_FILE="$BASE_DIR/_sidebar.md"
    echo "# Sidebar" > "$SIDEBAR_FILE"
    for SUBDIR in "${SUBDIRS[@]}"; do
        echo "- [$SUBDIR](/$SUBDIR/)" >> "$SIDEBAR_FILE"
        for MODULE in "${MODULES[@]}"; do
            echo "  - [$MODULE](/$SUBDIR/$MODULE.md)" >> "$SIDEBAR_FILE"
        done
    done

    echo "Documentation structure created successfully in $BASE_DIR"
}

# Run the function
create_structure
